﻿namespace UniCatalog_2023
{
    partial class Form13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label10 = new Label();
            textBox5 = new TextBox();
            comboBox4 = new ComboBox();
            label9 = new Label();
            label8 = new Label();
            comboBox2 = new ComboBox();
            label7 = new Label();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label6 = new Label();
            comboBox3 = new ComboBox();
            label5 = new Label();
            label4 = new Label();
            textBox2 = new TextBox();
            button2 = new Button();
            label1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(90, 109);
            label10.Name = "label10";
            label10.Size = new Size(132, 23);
            label10.TabIndex = 73;
            label10.Text = "Nume disciplina";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(90, 132);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(151, 30);
            textBox5.TabIndex = 72;
            // 
            // comboBox4
            // 
            comboBox4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "1", "2" });
            comboBox4.Location = new Point(90, 284);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(151, 31);
            comboBox4.TabIndex = 71;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(90, 257);
            label9.Name = "label9";
            label9.Size = new Size(81, 23);
            label9.TabIndex = 70;
            label9.Text = "Semestru";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(283, 338);
            label8.Name = "label8";
            label8.Size = new Size(101, 23);
            label8.TabIndex = 69;
            label8.Text = "An de studii";
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "1", "2", "3", "4" });
            comboBox2.Location = new Point(283, 364);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 31);
            comboBox2.TabIndex = 68;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(442, 262);
            label7.Name = "label7";
            label7.Size = new Size(144, 23);
            label7.TabIndex = 67;
            label7.Text = "Numar de credite";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(442, 285);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(218, 30);
            textBox4.TabIndex = 66;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(442, 209);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(218, 30);
            textBox3.TabIndex = 65;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(441, 109);
            label6.Name = "label6";
            label6.Size = new Size(219, 23);
            label6.TabIndex = 64;
            label6.Text = "Programul de care apartine";
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(442, 131);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(218, 31);
            comboBox3.TabIndex = 63;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(442, 186);
            label5.Name = "label5";
            label5.Size = new Size(96, 23);
            label5.TabIndex = 62;
            label5.Text = "Prescurtare";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(90, 185);
            label4.Name = "label4";
            label4.Size = new Size(116, 23);
            label4.TabIndex = 61;
            label4.Text = "Cod disciplina";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(90, 209);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(151, 30);
            textBox2.TabIndex = 60;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.RoyalBlue;
            button2.Location = new Point(90, 443);
            button2.Name = "button2";
            button2.Size = new Size(218, 48);
            button2.TabIndex = 59;
            button2.Text = "Modifica";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("UT Sans Medium", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(250, 32);
            label1.Name = "label1";
            label1.Size = new Size(193, 61);
            label1.TabIndex = 56;
            label1.Text = "Discipline";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.RoyalBlue;
            button1.Location = new Point(442, 443);
            button1.Name = "button1";
            button1.Size = new Size(218, 48);
            button1.TabIndex = 55;
            button1.Text = "Inapoi";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form13
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(704, 534);
            Controls.Add(label10);
            Controls.Add(textBox5);
            Controls.Add(comboBox4);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(comboBox2);
            Controls.Add(label7);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label6);
            Controls.Add(comboBox3);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form13";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Secretary";
            Load += Form13_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private TextBox textBox5;
        private ComboBox comboBox4;
        private Label label9;
        private Label label8;
        private ComboBox comboBox2;
        private Label label7;
        private TextBox textBox4;
        private TextBox textBox3;
        private Label label6;
        private ComboBox comboBox3;
        private Label label5;
        private Label label4;
        private TextBox textBox2;
        private Button button2;
        private Label label1;
        private Button button1;
    }
}