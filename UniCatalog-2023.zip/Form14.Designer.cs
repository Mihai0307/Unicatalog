﻿namespace UniCatalog_2023
{
    partial class Form14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            label3 = new Label();
            textBox1 = new TextBox();
            label10 = new Label();
            textBox5 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label6 = new Label();
            comboBox3 = new ComboBox();
            label5 = new Label();
            label4 = new Label();
            textBox2 = new TextBox();
            button2 = new Button();
            label1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(63, 408);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(140, 30);
            textBox7.TabIndex = 98;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(428, 330);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(235, 30);
            textBox6.TabIndex = 97;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(426, 304);
            label3.Name = "label3";
            label3.Size = new Size(112, 23);
            label3.TabIndex = 96;
            label3.Text = "Anul inscrierii";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(426, 408);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(237, 30);
            textBox1.TabIndex = 95;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(63, 135);
            label10.Name = "label10";
            label10.Size = new Size(121, 23);
            label10.TabIndex = 94;
            label10.Text = "Nume Student\r\n";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(63, 161);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(140, 30);
            textBox5.TabIndex = 93;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(426, 382);
            label9.Name = "label9";
            label9.Size = new Size(149, 23);
            label9.TabIndex = 92;
            label9.Text = "Media de inscriere";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(63, 386);
            label8.Name = "label8";
            label8.Size = new Size(44, 23);
            label8.TabIndex = 91;
            label8.Text = "CNP";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(426, 222);
            label7.Name = "label7";
            label7.Size = new Size(130, 23);
            label7.TabIndex = 90;
            label7.Text = "Numar Matricol";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(426, 248);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(237, 30);
            textBox4.TabIndex = 89;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(63, 330);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(140, 30);
            textBox3.TabIndex = 88;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(426, 135);
            label6.Name = "label6";
            label6.Size = new Size(237, 23);
            label6.TabIndex = 87;
            label6.Text = "Specializarea de care apartine";
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(426, 161);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(237, 31);
            comboBox3.TabIndex = 86;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(63, 304);
            label5.Name = "label5";
            label5.Size = new Size(96, 23);
            label5.TabIndex = 85;
            label5.Text = "Initiala tata\r\n";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(60, 222);
            label4.Name = "label4";
            label4.Size = new Size(143, 23);
            label4.TabIndex = 84;
            label4.Text = "Prenume Student";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(63, 248);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(140, 30);
            textBox2.TabIndex = 83;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.RoyalBlue;
            button2.Location = new Point(428, 498);
            button2.Name = "button2";
            button2.Size = new Size(235, 48);
            button2.TabIndex = 82;
            button2.Text = "Modifica";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("UT Sans Medium", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(236, 42);
            label1.Name = "label1";
            label1.Size = new Size(173, 61);
            label1.TabIndex = 79;
            label1.Text = "Studenti";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.RoyalBlue;
            button1.Location = new Point(63, 498);
            button1.Name = "button1";
            button1.Size = new Size(140, 48);
            button1.TabIndex = 78;
            button1.Text = "Inapoi";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form14
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(729, 624);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(label10);
            Controls.Add(textBox5);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label6);
            Controls.Add(comboBox3);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form14";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Secretary";
            Load += Form14_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox7;
        private TextBox textBox6;
        private Label label3;
        private TextBox textBox1;
        private Label label10;
        private TextBox textBox5;
        private Label label9;
        private Label label8;
        private Label label7;
        private TextBox textBox4;
        private TextBox textBox3;
        private Label label6;
        private ComboBox comboBox3;
        private Label label5;
        private Label label4;
        private TextBox textBox2;
        private Button button2;
        private Label label1;
        private Button button1;
    }
}