﻿namespace UniCatalog_2023
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button8 = new Button();
            button7 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            button9 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("UT Sans Medium", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(148, 51);
            label1.Name = "label1";
            label1.Size = new Size(377, 61);
            label1.TabIndex = 1;
            label1.Text = "Welcome, Secretary!";
            // 
            // button8
            // 
            button8.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button8.ForeColor = Color.RoyalBlue;
            button8.Location = new Point(44, 319);
            button8.Name = "button8";
            button8.Size = new Size(248, 48);
            button8.TabIndex = 17;
            button8.Text = " Discipline";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button7.ForeColor = Color.RoyalBlue;
            button7.Location = new Point(360, 319);
            button7.Name = "button7";
            button7.Size = new Size(248, 48);
            button7.TabIndex = 16;
            button7.Text = "Cataloage";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button5.ForeColor = Color.RoyalBlue;
            button5.Location = new Point(360, 243);
            button5.Name = "button5";
            button5.Size = new Size(248, 48);
            button5.TabIndex = 14;
            button5.Text = " Cadre didactice";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.RoyalBlue;
            button4.Location = new Point(44, 243);
            button4.Name = "button4";
            button4.Size = new Size(248, 48);
            button4.TabIndex = 13;
            button4.Text = "Programe de studii";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.RoyalBlue;
            button3.Location = new Point(44, 402);
            button3.Name = "button3";
            button3.Size = new Size(248, 48);
            button3.TabIndex = 12;
            button3.Text = "Grupe";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.RoyalBlue;
            button2.Location = new Point(360, 161);
            button2.Name = "button2";
            button2.Size = new Size(248, 48);
            button2.TabIndex = 11;
            button2.Text = "Studenți";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.RoyalBlue;
            button1.Location = new Point(44, 161);
            button1.Name = "button1";
            button1.Size = new Size(248, 48);
            button1.TabIndex = 10;
            button1.Text = "Ciclu de invatamant";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button9
            // 
            button9.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button9.ForeColor = Color.RoyalBlue;
            button9.Location = new Point(360, 402);
            button9.Name = "button9";
            button9.Size = new Size(248, 48);
            button9.TabIndex = 19;
            button9.Text = "Iesire";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(671, 502);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button8;
        private Button button7;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Button button9;
    }
}