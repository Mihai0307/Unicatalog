﻿namespace UniCatalog_2023
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
    }
}
